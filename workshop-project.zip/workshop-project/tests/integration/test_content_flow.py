"""End-to-end content submission and moderation flow."""
import pytest


async def test_submit_and_moderate_flow(client):
    # Create a user
    user_resp = await client.post(
        "/api/users/",
        json={"email": "carol@example.com", "display_name": "Carol", "role": "user"},
    )
    assert user_resp.status_code == 201
    user_id = user_resp.json()["id"]

    # Submit content
    content_resp = await client.post(
        "/api/content/",
        json={"author_id": user_id, "kind": "text", "body": "Hello world"},
    )
    assert content_resp.status_code == 201
    content_id = content_resp.json()["id"]

    # Moderator pulls the queue
    queue_resp = await client.get("/api/moderation/queue", params={"moderator_id": 42})
    assert queue_resp.status_code == 200
    queue = queue_resp.json()
    assert any(item["content_id"] == content_id for item in queue)


async def test_health_endpoint(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
