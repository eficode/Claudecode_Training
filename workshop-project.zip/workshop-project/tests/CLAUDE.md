# tests/ — Test Suite

## Stack

- **pytest** with `pytest-asyncio` (mode = auto, see `pyproject.toml`)
- **httpx** with ASGI transport for HTTP tests — no need to start a real server

## Boundaries

| Folder | What goes here | What does NOT |
|--------|----------------|---------------|
| `tests/unit/` | Service-layer logic, pure functions | Anything that hits HTTP or a real DB |
| `tests/integration/` | Routes via the `client` fixture | Tests that mock the service layer (use `unit/`) |

## Fixtures

- `client` (from `conftest.py`) — async httpx client wired to the FastAPI app
- `user_payload` — minimal valid `UserCreate` payload for reuse

## Common Mistakes

- Forgetting `async def` on tests (asyncio_mode = auto handles the decoration)
- Sharing state between tests via the in-memory stores — `users_service._USERS` survives across tests. Add a fixture to reset if your test depends on isolation.
- Asserting on dict ordering (Python dicts preserve insertion order, but don't rely on it across stores).

## Running

```bash
pytest -q                       # quiet
pytest -k moderation            # only matching tests
pytest tests/unit/              # only unit
pytest --cov=src                # with coverage (if pytest-cov installed)
```
