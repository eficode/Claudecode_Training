"""Unit tests for the moderation service decision logic."""
import pytest

from src.api.schemas import ContentCreate, ModerationDecision
from src.services import content as content_service
from src.services import moderation as moderation_service


async def test_reject_records_audit_entry():
    item = await content_service.create(
        ContentCreate(author_id=1, kind="text", body="possibly spam")
    )
    decision = ModerationDecision(
        content_id=item.id, moderator_id=99, decision="reject", reason="spam"
    )
    await moderation_service.record_decision(decision)

    log = moderation_service.get_audit_log()
    assert any(entry["content_id"] == item.id and entry["decision"] == "rejected" for entry in log)


async def test_cannot_moderate_twice():
    item = await content_service.create(
        ContentCreate(author_id=1, kind="text", body="ok")
    )
    decision = ModerationDecision(
        content_id=item.id, moderator_id=99, decision="approve"
    )
    await moderation_service.record_decision(decision)
    with pytest.raises(ValueError, match="content_already_moderated"):
        await moderation_service.record_decision(decision)
