"""Unit-ish tests for the users service. Workshop note: uses in-memory store."""
import pytest

from src.api.schemas import UserCreate
from src.services import users as users_service


async def test_create_then_get():
    user = await users_service.create(
        UserCreate(email="bob@example.com", display_name="Bob", role="user")
    )
    fetched = await users_service.get(user.id)
    assert fetched is not None
    assert fetched.email == "bob@example.com"


async def test_get_by_email_returns_none_for_unknown():
    result = await users_service.get_by_email("nobody@example.com")
    assert result is None
