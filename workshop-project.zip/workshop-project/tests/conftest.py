"""Pytest fixtures shared across the test suite."""
import pytest
from httpx import ASGITransport, AsyncClient

from src.api import app


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
def user_payload():
    return {
        "email": "alice@example.com",
        "display_name": "Alice",
        "role": "user",
    }
