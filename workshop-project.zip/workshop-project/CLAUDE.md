# Protodrake

Content moderation API. FastAPI + Postgres + Redis. See `docs/architecture.md` for the full picture.

## Stack
- Python 3.11, FastAPI, SQLAlchemy 2 (async), Redis, Pydantic v2
- Tests: pytest + httpx
- Lint: ruff (line-length 100)

## Layout
| Path | Purpose | More info |
|------|---------|-----------|
| `src/api/` | Routes + Pydantic schemas | `src/api/CLAUDE.md` |
| `src/services/` | Business logic | `src/CLAUDE.md` |
| `src/db/` | SQLAlchemy models + session | `src/CLAUDE.md` |
| `src/lib/` | Errors, cache helpers | `src/CLAUDE.md` |
| `tests/` | pytest suite | `tests/CLAUDE.md` |
| `infra/` | Docker + GitHub Actions | `infra/CLAUDE.md` |
| `docs/specs/` | Design specs | `docs/specs/CLAUDE.md` |

## Conventions
- `route → service → db` layering. Routes are thin; never call db from routes.
- All public functions are type-annotated (`mypy --strict` is the goal).
- Errors: raise `AppError` subclasses from `src/lib/errors.py`. Don't raise plain `Exception`.
- Pagination: cursor or offset+limit, never both in one endpoint.

## Commands
- Run dev server: `uvicorn src.api:app --reload`
- Run tests: `pytest -q`
- Lint: `ruff check src/ tests/`
- Format: `ruff format src/ tests/`

## Sub-Agents
- See `.claude/agents/` — backend, frontend, test (Haiku-pinned), infra
- Use `/agents` to inspect or generate new ones
