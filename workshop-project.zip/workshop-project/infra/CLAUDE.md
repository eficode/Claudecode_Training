# infra/ — Deployment & CI

## What's Here

- `Dockerfile` — multi-stage Python image, non-root user, ~150 MB final
- `docker-compose.yml` — local stack (api + postgres + redis) for development
- `.github/workflows/ci.yml` — lint + test on every PR
- `.github/workflows/claude-review.yml` — headless Claude review on PRs (calls `scripts/ci/claude-review.sh`)

## Rules

- Never push to `main` directly — PR required
- Never commit secrets — secrets go in GitHub repository secrets (`ANTHROPIC_API_KEY` is already wired)
- Workflow changes get extra scrutiny — single point of failure for the team

## Common Mistakes

- Adding a new env var to compose but forgetting `.env.example`
- Hardcoding the image tag in `claude-review.yml` instead of using `${{ github.sha }}`
- Forgetting to bump the Python minor version in both `Dockerfile` and `pyproject.toml`
