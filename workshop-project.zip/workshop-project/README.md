# Workshop project — Content Moderation API

A fictional internal API used as the working repo for the **Claude Code Day 2 Workshop**. The codebase simulates a small but realistic FastAPI service so the workshop exercises feel like real work.

> 📚 **Workshop participants — start at [`KATAS.md`](KATAS.md).** That file maps each kata exercise to this repo and tells you what to do.

## What This (Fake) Service Does

This is a content moderation API. Users submit content (images, text), moderators triage it through a queue, and the system maintains an audit trail. Three main resources:

- `/api/users` — user CRUD, role management
- `/api/content` — submit, list, fetch content items
- `/api/moderation` — moderation queue, decisions, audit log

## Tech Stack (Fictional but Plausible)

- **API**: FastAPI + Pydantic v2
- **DB**: PostgreSQL via SQLAlchemy 2.x
- **Cache**: Redis for moderation queue
- **Tests**: pytest + httpx
- **CI**: GitHub Actions
- **Deploy**: Docker → AWS ECS (or GCP Cloud Run)

## Local Development

```bash
# Set up a virtualenv
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e ".[dev]"

# Copy env template
cp .env.example .env

# Run the API
uvicorn src.api:app --reload

# Run tests
pytest

# Lint
ruff check src/ tests/
```

## Project Layout

```
workshop-project/
├── src/                # Application code (see src/CLAUDE.md)
│   ├── api/            # FastAPI routes + schemas
│   ├── services/       # Business logic
│   ├── db/             # Models + session
│   └── lib/            # Errors, cache helpers
├── tests/              # pytest suite (see tests/CLAUDE.md)
├── infra/              # Docker, CI workflows (see infra/CLAUDE.md)
├── docs/               # Architecture docs + specs
├── scripts/
│   ├── mcp/            # Bundled MCP server (kata 07)
│   └── ci/             # Headless Claude in CI
├── .claude/            # Workshop-grade Claude Code config
│   ├── agents/         # Subagent specs (with model pinning)
│   ├── rules/          # Path-scoped style/security/test rules
│   ├── skills/         # Custom slash commands (progressive disclosure)
│   └── hooks/          # Lifecycle automation
└── WORKSHOP/           # The workshop kata content itself
```

## Note: This Is a Fake Project

The code compiles and the tests would run, but the business logic is intentionally light. **Don't deploy this anywhere.** It exists so the workshop has a realistic surface to explore: enough files for Claude to navigate, enough patterns to demonstrate the toolchain.
