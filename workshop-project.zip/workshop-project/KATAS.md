# Workshop Katas — Running Them in *This* Repo

The original katas in `WORKSHOP/day2-katas/` say things like "create `/tmp/kata-05`" because they assume a clean slate. **For this workshop, ignore those setup steps.** This repo IS the project. All paths in the exercises map to paths in this repo.

This file is your guide: for each kata, what's already done for you, what's left for you to do, and where to look.

> Some hooks, skills, and configs are pre-installed so you can see what a real Claude Code setup looks like. The exercises ask you to **add to** or **modify** the existing config, not to build from scratch.

---

## Before You Start

1. Make sure Claude Code is installed: `claude --version` should print a version
2. Install the MCP server dependencies (one-time):
   ```bash
   cd scripts/mcp && npm install && cd ../..
   ```
3. Optionally, install Python dev deps to run tests:
   ```bash
   python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -e ".[dev]"
   ```
4. From the project root, start a session:
   ```bash
   claude
   ```

When you start Claude:
- The custom **statusline** appears at the bottom showing model + context % + cost (kata 03)
- The `SessionStart` hook injects `TODO.md` into context (kata 06)
- The MCP server `workshop-tools` is auto-loaded (kata 07) — verify with `/mcp`

---

## Kata 01 — Agent Modes & Effort Levels

📖 Full exercise: [`WORKSHOP/day2-katas/01-agent-modes/`](WORKSHOP/day2-katas/01-agent-modes/)

**Skip the kata's `/tmp/kata-01` setup.** Work in this repo.

### Fundamentals — try in this repo
- **Task 1 (Plan mode)**: run `claude --permission-mode plan` from the project root. Then ask:
  > "Analyze `src/api/routes/users.py` and suggest how to add a PATCH endpoint for updating display_name. Don't change anything, just plan."
- **Task 2 (Shift+Tab)**: cycle modes inside a normal session. Watch the indicator.
- **Task 3 (Auto-accept)**: ask Claude to add a comment to any file in `src/lib/`.

### Novel Layer — try in this repo
- **Task 4 (Effort levels)**:
  ```
  /effort low
  Add a one-line module docstring to src/lib/cache.py
  ```
  Then:
  ```
  /effort high
  Plan how to wire the in-memory stores in src/services/ to real SQLAlchemy. Plan mode only.
  ```
- **Task 5 (Background)**: append `&` to a prompt:
  ```
  Read every file in src/ and produce a one-page summary of the architecture &
  ```
- **Task 6 (Agent View)**: in a separate terminal, run `claude agents` to see your background session.
- **Task 7 (Headless)**:
  ```bash
  claude -p "List the public route handlers in src/api/routes/. Output JSON only."
  ```

---

## Kata 02 — Security & Containment

📖 Full exercise: [`WORKSHOP/day2-katas/02-security-containment/`](WORKSHOP/day2-katas/02-security-containment/)

### What's pre-installed
- `.claude/settings.json` — permission allow/deny rules covering pytest, ruff, uvicorn, git read commands
- `.claude/settings.json` — denies `Read(.env)`, `Read(secrets/**)`, `Read(*.pem)`, `Bash(rm -rf *)`
- `.claudeignore` — keeps Claude from auto-reading `node_modules`, `.venv`, secrets, build artifacts
- `.claude/hooks/check-secrets.sh` — blocks edits introducing hardcoded API keys (regex-based)

### Fundamentals — verify what's there
- **Task 1 (Rules)**: read `.claude/settings.json` and explain the `permissions` block to a teammate.
- **Task 2 (Test rules)**: start `claude`. Try:
  1. `"Run git status"` — auto-approved
  2. `"Read the .env file"` — denied
  3. `"Delete the src folder with rm -rf"` — denied (caught by both deny rule AND the `block-delete` hook)
  4. `"Read src/api/routes/users.py"` — allowed (read-only)
- **Task 3 (`/permissions`)**: run `/permissions` in a Claude session, browse the interactive manager.

### Novel Layer — extend what's there
- **Task 4 (`.claudeignore`)**: already in place. Verify with:
  > "Use Glob to list every file in this project."
  Notice that `.env.example` shows but `.env` doesn't (and never will, even if you create one).
- **Task 5 (Prompt-type hook — AI as security judge)**: this is NOT pre-installed. Add it. Edit `.claude/settings.json` and append a prompt-type hook under `PreToolUse` for matcher `"Bash"`:
  ```json
  {
    "matcher": "Bash",
    "hooks": [
      {
        "type": "prompt",
        "prompt": "Evaluate this Bash command: $TOOL_INPUT\n\nIs it destructive, exfiltrative, or beyond a normal dev workflow? Reply with exactly BLOCK: <reason> or ALLOW.",
        "timeout": 5
      }
    ]
  }
  ```
  Restart Claude and try: `"Run: find / -name '*.pem' -exec cat {} \;"` — the Haiku judge should block it with reasoning.
- **Task 6 (HTTP hook — optional)**: stand up a tiny Python listener (kata 02 step 6 has the snippet). Point a `PostToolUse` HTTP hook at it. Verify events flow.

---

## Kata 03 — Variables, Configuration & Statusline

📖 Full exercise: [`WORKSHOP/day2-katas/03-variables/`](WORKSHOP/day2-katas/03-variables/)

### What's pre-installed
- **Root `CLAUDE.md`** — lean (under 60 lines), points to subdirectory CLAUDE.mds
- **Subdirectory `CLAUDE.md` files** — `src/`, `src/api/`, `tests/`, `infra/`, `docs/specs/`
- **`CLAUDE.local.md.example`** — template; copy to `CLAUDE.local.md` (gitignored) and customize
- **`.claude/settings.json`** — already sets `env.ANTHROPIC_MODEL`, `CLAUDE_CODE_SUBAGENT_MODEL`, `ANTHROPIC_SMALL_FAST_MODEL`
- **`.claude/settings.local.json.example`** — template; copy and customize
- **`.claude/statusline.sh`** + **`.claude/statusline.ps1`** — working statusline showing model, branch, context %, cost
- **Statusline is wired in `.claude/settings.json`** — you'll see it the moment you launch Claude

### Fundamentals — explore what's there
- **Task 1**: read root `CLAUDE.md`. Ask Claude:
  > "What conventions does this project use?"
  It should answer entirely from CLAUDE.md without reading other files.
- **Task 2 (Personal overrides)**:
  ```bash
  cp CLAUDE.local.md.example CLAUDE.local.md
  ```
  Edit it. Restart Claude and ask:
  > "How should you communicate with me?"
- **Task 3 (Settings layering)**:
  ```bash
  cp .claude/settings.local.json.example .claude/settings.local.json
  ```
  Note the extra permissions and `MAX_THINKING_TOKENS` cap that don't exist in the shared settings.

### Novel Layer — explore what's there
- **Task 4 (Statusline)**: already live. Look at the bottom of your terminal. The numbers update on every turn.
- **Task 5 (Customize statusline)**: edit `.claude/statusline.sh` — add the cost-per-turn delta, or input/output token counts, or whatever you find useful. Restart Claude to see the change.
- **Task 6 (Subagent routing)**: already wired. Ask:
  > "Use a subagent to summarize what each file in src/services/ does."
  The subagent will run on Haiku (cheap) per `CLAUDE_CODE_SUBAGENT_MODEL`.
- **Task 7 (Polished statusline)**: optional. Try installing a marketplace one:
  ```
  /plugin marketplace add Owloops/claude-powerline
  /plugin install claude-powerline@claude-powerline
  /powerline
  ```

---

## Kata 04 — Hotkeys & Slash Commands

📖 Full exercise: [`WORKSHOP/day2-katas/04-hotkeys/`](WORKSHOP/day2-katas/04-hotkeys/)

This kata has no setup — just hands-on with shortcuts. The whole exercise runs in any Claude session, including one started in this repo.

Use this repo's existing files for the practice prompts:

- **Task 1 (Essentials)**: practice `Ctrl+L`, `Shift+Tab`, `Esc Esc`, `Ctrl+R`
- **Task 2 (Multiline)**: write a 3-line prompt about extending `src/api/routes/moderation.py`
- **Task 3 (Vim mode)**: `/config` → Editor mode → vim. Practice. Switch back.

Novel-layer tasks run as written in the kata. Use real prompts about this codebase:

- `/effort high` → "Design rate limiting for `/api/content/`. Plan only."
- `/context` → see how this session's context is spent
- `/mcp` → confirm `workshop-tools` is loaded
- `/plugin` → browse the official marketplace

---

## Kata 05 — Skills & Plugin Marketplaces

📖 Full exercise: [`WORKSHOP/day2-katas/05-skills/`](WORKSHOP/day2-katas/05-skills/)

### What's pre-installed
- **`/review`** — fully progressive-disclosed skill in `.claude/skills/review/` (SKILL.md + `references/python.md`, `javascript.md`, `general.md` + `scripts/complexity.sh`)
- **`/deploy`** — fully progressive-disclosed skill in `.claude/skills/deploy/` (SKILL.md + AWS/GCP/rollback references + precheck.sh + notify.sh)
- **`/status`** — dynamic skill with `!` git injection in `.claude/skills/status/`
- **`/db-migrate`** — single-file skill in `.claude/skills/db-migrate/`

### Fundamentals — use what's there
- **Task 1**: try the pre-installed review skill:
  ```
  /review src/api/routes/users.py
  ```
  Watch Claude read the file, then `references/python.md`, then run `scripts/complexity.sh`.
- **Task 2**: try `/status` — it injects live git context.

### Novel Layer — extend what's there
- **Task 3**: read `.claude/skills/review/` to internalize the progressive-disclosure pattern. Then:
  - Add a new reference: `.claude/skills/review/references/security.md` with security-focused checks (SQL injection, hardcoded credentials, unsafe deserialization)
  - Update `SKILL.md` to point to it when the file path contains `api/` or `auth/`
  - Test: `/review src/api/routes/moderation.py` — Claude should now consult the security reference too
- **Task 4 (Plugin marketplace)**:
  ```
  /plugin
  ```
  Browse the official Anthropic marketplace. Install one — recommended: `code-review@claude-plugins-official` for comparison with the `/review` skill above.
- **Task 5 (Stretch — private marketplace)**: package the pre-installed `/review` skill as a private marketplace plugin. Kata 05 step 5 has the full recipe.

---

## Kata 06 — Hooks Mastery

📖 Full exercise: [`WORKSHOP/day2-katas/06-hooks/`](WORKSHOP/day2-katas/06-hooks/)

### What's pre-installed
- `.claude/hooks/log-tools.sh` (+ `.ps1`) — PostToolUse async logging → `claude-tool-log.txt`
- `.claude/hooks/block-delete.sh` (+ `.ps1`) — PreToolUse Bash blocker
- `.claude/hooks/check-secrets.sh` (+ `.ps1`) — PreToolUse Edit|Write secret detector
- `.claude/hooks/prod-guard.sh` (+ `.ps1`) — UserPromptSubmit context injector for "prod"/"production" mentions
- `.claude/hooks/session-todos.sh` (+ `.ps1`) — SessionStart, loads TODO.md
- `.claude/hooks/backup-on-compact.sh` (+ `.ps1`) — PreCompact, saves transcript to `backups/`
- `.claude/hooks/inject-context.sh` — NOT wired by default; reserved for kata 06 task 3

All wired in `.claude/settings.json` already (except `inject-context.sh`).

### Fundamentals — explore what's there
- **Task 1 (Logging)**: do anything in a Claude session. Then:
  ```bash
  cat claude-tool-log.txt
  ```
  Note: this hook is `async: true` — doesn't block Claude.
- **Task 2 (Blocking)**: try:
  > "Run: rm -rf src/"
  Watch it bounce with the hook's error message in stderr.

### Novel Layer — explore + extend
- **Task 3 (UserPromptSubmit injection)**: the `prod-guard` hook is already wired. Test:
  > "Deploy the api to production"
  Watch Claude's response acknowledge the prod-context warning before doing anything.
- **Task 4 (SessionStart)**: already wired. Start a new session and ask:
  > "What should I work on first?"
  Claude already knows the contents of `TODO.md`.
- **Task 5 (Prompt-type hook — AI security judge)**: add to `.claude/settings.json` under `PreToolUse`:
  ```json
  {
    "matcher": "Edit|Write",
    "hooks": [
      {
        "type": "prompt",
        "prompt": "Examine this edit. Does it introduce a hardcoded password, API key, AWS access key, GitHub token, or any other secret? Reply with exactly BLOCK: <reason> or ALLOW.\n\n$TOOL_INPUT",
        "timeout": 5
      }
    ]
  }
  ```
  This complements the regex-based `check-secrets.sh` with a Haiku judge that catches things regex misses. Test by asking Claude to add `STRIPE_KEY = "sk_live_..."` to any file.
- **Task 6 (PreCompact backup)**: already wired. Have a longish session, watch context fill in the statusline. When compaction triggers (or run `/handoff`):
  ```bash
  ls backups/
  ```
- **Task 7 (`/hooks` viewer)**: in a session, run `/hooks` to inspect the active config (read-only since March 2026).

---

## Kata 07 — Custom MCP Server with Elicitation

📖 Full exercise: [`WORKSHOP/day2-katas/07-custom-mcp-server/`](WORKSHOP/day2-katas/07-custom-mcp-server/)

### What's pre-installed
- `scripts/mcp/server.js` — fully working MCP server with `generate_uuid`, `count_words`, `format_json`, an **elicitation-driven `deploy` tool**, and a `project://info` resource
- `.mcp.json` at the project root — registers the server for this project

### Setup
```bash
cd scripts/mcp && npm install && cd ../..
```

### Fundamentals — use what's there
- **Task 1 (Verify)**: in Claude, run `/mcp` — should list `workshop-tools` with 4 tools + 1 resource.
- **Task 2 (Try the tools)**:
  - `"Generate a UUID"`
  - `"Count the words in: The quick brown fox jumps over the lazy dog"`
  - `"Format this JSON: {\"name\":\"test\",\"value\":42}"`
- **Task 3 (Read the source)**: open `scripts/mcp/server.js`. Match each tool definition to the kata's fundamentals section.

### Novel Layer — the elicitation tool
- **Task 4 (Elicitation in action)**: ask Claude:
  > "Deploy the user-service"
  A form dialog opens in your terminal asking for env (dev/staging/production) and a confirmation checkbox. Fill it in. Watch the tool resume with your answers.
- **Task 5 (Read the elicitation code)**: in `scripts/mcp/server.js`, study the `deploy` tool. Notice:
  - `srv.elicitInput({ message, requestedSchema })` is the call
  - Response has `.action` (accept/decline) and `.content` (form values)
  - The tool can refuse to proceed if the user un-checks the confirm box
- **Task 6 (Extend)**: add a new tool with elicitation — e.g., `seed_db` that asks "how many fake users / content items to generate?" via a form before populating the in-memory stores.
- **Task 7 (Stretch — bundle as plugin)**: kata 07 step 5 walks through packaging this whole MCP server as an installable plugin so `/plugin install` does the wiring instead of `.mcp.json`.

---

## Kata 08 — Expert Topics (Reference)

📖 [`WORKSHOP/day2-katas/08-expert-topics/`](WORKSHOP/day2-katas/08-expert-topics/)

No hands-on tasks. For fast finishers and self-study. Covers:

- Agent Teams & Agent View (some of which you already saw in kata 01)
- Plugin marketplaces public + private (kata 05 deeper dive)
- Headless workflows (`claude -p`, Remote Control, the Agent SDK)
- Token economics & context engineering

Worth reading even if you don't do any of the exercises today.

---

## Where Everything Maps

| Workshop concept | Where in this repo |
|------------------|---------------------|
| Lean root CLAUDE.md | `CLAUDE.md` |
| Subdirectory CLAUDE.mds | `src/CLAUDE.md`, `src/api/CLAUDE.md`, `tests/CLAUDE.md`, `infra/CLAUDE.md`, `docs/specs/CLAUDE.md` |
| Personal overrides | `CLAUDE.local.md.example` (copy to `CLAUDE.local.md`) |
| Token-saver | `.claudeignore` |
| Project settings | `.claude/settings.json` |
| Personal settings template | `.claude/settings.local.json.example` |
| Statusline | `.claude/statusline.sh` + `.ps1` |
| Subagents w/ model pinning | `.claude/agents/{backend,frontend,test,infra}.md` |
| Path-scoped rules | `.claude/rules/{code-style,api-guidelines,testing,security}.md` |
| Progressive-disclosure skill (1) | `.claude/skills/review/` |
| Progressive-disclosure skill (2) | `.claude/skills/deploy/` |
| Dynamic-content skill | `.claude/skills/status/SKILL.md` |
| Single-file skill | `.claude/skills/db-migrate/SKILL.md` |
| All 6 active hooks | `.claude/hooks/` (`.sh` + `.ps1` variants) |
| MCP server config | `.mcp.json` |
| MCP server source | `scripts/mcp/server.js` |
| Headless CI integration | `scripts/ci/claude-review.sh` + `infra/.github/workflows/claude-review.yml` |
| Workshop docs | `WORKSHOP/day2-katas/` |
