"""Redis-style cache helpers. In-memory shim for the workshop."""
from collections import deque
from typing import Any

_QUEUES: dict[str, deque[Any]] = {}


async def enqueue(name: str, value: Any) -> None:
    _QUEUES.setdefault(name, deque()).append(value)


async def dequeue(name: str) -> Any:
    q = _QUEUES.get(name)
    if not q:
        return None
    return q.popleft()


async def queue_length(name: str) -> int:
    return len(_QUEUES.get(name, ()))
