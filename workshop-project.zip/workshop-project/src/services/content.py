"""Content service — submission and retrieval."""
from datetime import datetime, timezone

from src.api.schemas import ContentCreate, ContentOut
from src.lib.cache import enqueue

_CONTENT: dict[int, ContentOut] = {}
_NEXT_ID = 1


async def create(payload: ContentCreate) -> ContentOut:
    global _NEXT_ID
    item = ContentOut(
        id=_NEXT_ID,
        author_id=payload.author_id,
        kind=payload.kind,
        body=payload.body,
        submitted_at=datetime.now(timezone.utc),
        status="pending",
    )
    _CONTENT[_NEXT_ID] = item
    _NEXT_ID += 1
    return item


async def get(content_id: int) -> ContentOut | None:
    return _CONTENT.get(content_id)


async def list_items(author_id: int | None = None, limit: int = 50) -> list[ContentOut]:
    items = list(_CONTENT.values())
    if author_id is not None:
        items = [item for item in items if item.author_id == author_id]
    return items[:limit]


async def enqueue_for_moderation(content_id: int) -> None:
    """Push content_id onto the moderation queue (Redis in prod, in-memory here)."""
    await enqueue("moderation:queue", content_id)


async def set_status(content_id: int, status: str) -> None:
    if content_id in _CONTENT:
        _CONTENT[content_id] = _CONTENT[content_id].model_copy(update={"status": status})
