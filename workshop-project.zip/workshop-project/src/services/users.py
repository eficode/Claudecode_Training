"""User service — business logic for /api/users."""
from datetime import datetime, timezone

from src.api.schemas import UserCreate, UserOut

# NOTE: In-memory store for the workshop. Real code uses src/db/.
_USERS: dict[int, UserOut] = {}
_NEXT_ID = 1


async def list_users(limit: int = 50, offset: int = 0) -> list[UserOut]:
    items = list(_USERS.values())
    return items[offset : offset + limit]


async def get(user_id: int) -> UserOut | None:
    return _USERS.get(user_id)


async def get_by_email(email: str) -> UserOut | None:
    for user in _USERS.values():
        if user.email == email:
            return user
    return None


async def create(payload: UserCreate) -> UserOut:
    global _NEXT_ID
    user = UserOut(
        id=_NEXT_ID,
        email=payload.email,
        display_name=payload.display_name,
        role=payload.role,
        created_at=datetime.now(timezone.utc),
    )
    _USERS[_NEXT_ID] = user
    _NEXT_ID += 1
    return user
