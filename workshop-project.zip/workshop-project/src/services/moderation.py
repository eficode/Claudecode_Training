"""Moderation service — queue management and decisions."""
from datetime import datetime, timedelta, timezone

from src.api.schemas import ModerationDecision, QueueItem
from src.lib.cache import dequeue
from src.services import content as content_service

_AUDIT_LOG: list[dict] = []


async def fetch_queue(moderator_id: int, limit: int = 20) -> list[QueueItem]:
    items: list[QueueItem] = []
    claim_until = datetime.now(timezone.utc) + timedelta(minutes=10)
    for _ in range(limit):
        content_id = await dequeue("moderation:queue")
        if content_id is None:
            break
        item = await content_service.get(content_id)
        if item is None:
            continue
        items.append(
            QueueItem(
                content_id=item.id,
                kind=item.kind,
                preview=item.body[:120],
                claimed_until=claim_until,
            )
        )
    return items


async def record_decision(decision: ModerationDecision) -> None:
    item = await content_service.get(decision.content_id)
    if item is None:
        raise ValueError("content_not_found")
    if item.status != "pending":
        raise ValueError("content_already_moderated")
    new_status = "approved" if decision.decision == "approve" else "rejected"
    await content_service.set_status(decision.content_id, new_status)
    _AUDIT_LOG.append(
        {
            "content_id": decision.content_id,
            "moderator_id": decision.moderator_id,
            "decision": new_status,
            "reason": decision.reason,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
    )


def get_audit_log() -> list[dict]:
    """Used by tests and admin endpoints."""
    return list(_AUDIT_LOG)
