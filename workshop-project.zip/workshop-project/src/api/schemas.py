"""Pydantic schemas — shared between routes and services."""
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field


class UserCreate(BaseModel):
    email: EmailStr
    display_name: str = Field(min_length=1, max_length=80)
    role: Literal["user", "moderator", "admin"] = "user"


class UserOut(BaseModel):
    id: int
    email: EmailStr
    display_name: str
    role: str
    created_at: datetime


class ContentCreate(BaseModel):
    author_id: int
    kind: Literal["text", "image"]
    body: str = Field(max_length=8_000)


class ContentOut(BaseModel):
    id: int
    author_id: int
    kind: str
    body: str
    submitted_at: datetime
    status: Literal["pending", "approved", "rejected"]


class QueueItem(BaseModel):
    content_id: int
    kind: str
    preview: str
    claimed_until: datetime


class ModerationDecision(BaseModel):
    content_id: int
    moderator_id: int
    decision: Literal["approve", "reject"]
    reason: str | None = Field(default=None, max_length=500)
