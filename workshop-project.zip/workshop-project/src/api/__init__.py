"""FastAPI application entry point."""
from fastapi import FastAPI

from src.api.routes import content, moderation, users
from src.lib.errors import register_exception_handlers

app = FastAPI(
    title="Protodrake API",
    version="0.1.0",
    description="Internal content moderation service",
)

app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(content.router, prefix="/api/content", tags=["content"])
app.include_router(moderation.router, prefix="/api/moderation", tags=["moderation"])

register_exception_handlers(app)


@app.get("/health")
async def health() -> dict[str, str]:
    """Liveness probe."""
    return {"status": "ok"}
