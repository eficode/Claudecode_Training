"""Content submission and retrieval routes."""
from fastapi import APIRouter, HTTPException, status

from src.api.schemas import ContentCreate, ContentOut
from src.services import content as content_service

router = APIRouter()


@router.post("/", response_model=ContentOut, status_code=status.HTTP_201_CREATED)
async def submit_content(payload: ContentCreate):
    """Submit a piece of content for moderation. Enqueues to moderation queue."""
    item = await content_service.create(payload)
    await content_service.enqueue_for_moderation(item.id)
    return item


@router.get("/", response_model=list[ContentOut])
async def list_content(author_id: int | None = None, limit: int = 50):
    return await content_service.list_items(author_id=author_id, limit=limit)


@router.get("/{content_id}", response_model=ContentOut)
async def get_content(content_id: int):
    item = await content_service.get(content_id)
    if not item:
        raise HTTPException(status_code=404, detail="content_not_found")
    return item
