"""Moderation queue and decisions."""
from fastapi import APIRouter, HTTPException

from src.api.schemas import ModerationDecision, QueueItem
from src.services import moderation as moderation_service

router = APIRouter()


@router.get("/queue", response_model=list[QueueItem])
async def get_queue(moderator_id: int, limit: int = 20):
    """Fetch the next batch of items for a moderator. Items are claimed for 10 minutes."""
    return await moderation_service.fetch_queue(moderator_id=moderator_id, limit=limit)


@router.post("/decisions")
async def submit_decision(decision: ModerationDecision):
    """Submit a moderation decision. Writes to the audit log."""
    try:
        await moderation_service.record_decision(decision)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"status": "recorded"}
