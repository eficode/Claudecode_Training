"""User CRUD routes."""
from fastapi import APIRouter, Depends, HTTPException, status

from src.api.schemas import UserCreate, UserOut
from src.services import users as users_service

router = APIRouter()


@router.get("/", response_model=list[UserOut])
async def list_users(limit: int = 50, offset: int = 0):
    """List users with cursor-based pagination."""
    return await users_service.list_users(limit=limit, offset=offset)


@router.post("/", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(payload: UserCreate):
    """Create a new user. Email must be unique."""
    existing = await users_service.get_by_email(payload.email)
    if existing:
        raise HTTPException(status_code=409, detail="email_already_exists")
    return await users_service.create(payload)


@router.get("/{user_id}", response_model=UserOut)
async def get_user(user_id: int):
    user = await users_service.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="user_not_found")
    return user
