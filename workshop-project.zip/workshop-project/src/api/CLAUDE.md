# src/api/ — Route Layer

## Rules

- Routes validate, dispatch, and translate errors. They do not contain business logic.
- Every endpoint declares a `response_model` for FastAPI to serialize through.
- Use `status_code=status.HTTP_201_CREATED` on POST endpoints that create resources.
- Authentication & authorization will live in middleware (TODO — not implemented yet).

## Naming

| Verb | Function name |
|------|---------------|
| GET list | `list_<resource>` |
| GET one | `get_<resource>` |
| POST create | `create_<resource>` or `submit_<resource>` for queue-style |
| PATCH update | `update_<resource>` |
| DELETE | `delete_<resource>` |

## Common Mistakes

- Returning the SQLAlchemy model directly — always go through a Pydantic schema (`ContentOut`, `UserOut`).
- Forgetting to register a new router in `src/api/__init__.py`.
- Mixing `raise HTTPException` and `raise AppError` — pick one per route. Prefer `AppError`.
