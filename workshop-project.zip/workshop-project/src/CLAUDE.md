# src/ — Application Code

Layering rule (mandatory): **route → service → db/lib**. Routes are thin handlers; never call DB from a route.

## Patterns

### Adding a new endpoint

1. Add the Pydantic schemas to `src/api/schemas.py`
2. Add the route handler in `src/api/routes/<resource>.py`
3. Add business logic in `src/services/<resource>.py`
4. Add DB queries in `src/db/` (when wired up — currently in-memory)
5. Write tests in `tests/unit/test_<resource>.py` (logic) and `tests/integration/` (HTTP)

### Error handling

Raise `AppError` subclasses (`NotFoundError`, `ConflictError`, `ValidationError`) — never plain `Exception`. The handler in `src/lib/errors.py` translates them to consistent JSON responses with an `error` code.

### Async everywhere

All service and route functions are `async`. The in-memory shims in `src/services/` are async even though they don't need to be, to match the real signature.

### Imports

Absolute imports from `src.*`. No relative imports across the service / route boundary.
