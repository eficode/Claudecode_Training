#!/bin/bash
# UserPromptSubmit — inject a production-context warning when user mentions prod.
# Anything printed to stdout is prepended to the user prompt (Claude sees it).
source "$(dirname "$0")/_lib.sh"

INPUT=$(cat)
PROMPT=$(json_get "$INPUT" prompt "")

if echo "$PROMPT" | grep -qiE '\b(prod|production|live|customers?)\b'; then
  cat <<'WARN'

⚠️  PRODUCTION CONTEXT DETECTED
The user's prompt mentions production. Any change here is high-stakes.
- Default to plan mode unless the user explicitly says "execute" or "ship"
- Refuse destructive operations unless explicitly confirmed
- For deploys, follow .claude/skills/deploy/SKILL.md exactly

WARN
fi
exit 0
