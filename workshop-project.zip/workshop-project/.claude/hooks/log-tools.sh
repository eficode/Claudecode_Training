#!/bin/bash
# PostToolUse — append every tool call to a local log. Async — does not gate Claude.
source "$(dirname "$0")/_lib.sh"

INPUT=$(cat)
TOOL=$(json_get "$INPUT" tool_name unknown)
TS=$(date '+%H:%M:%S')
echo "[$TS] $TOOL" >> claude-tool-log.txt
exit 0
