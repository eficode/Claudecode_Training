# UserPromptSubmit — production keyword guard.
$inputJson = $input | Out-String
$data = $inputJson | ConvertFrom-Json -ErrorAction SilentlyContinue
$prompt = if ($data.prompt) { $data.prompt } else { "" }

if ($prompt -match '\b(prod|production|live|customers?)\b') {
    Write-Output ""
    Write-Output "⚠️  PRODUCTION CONTEXT DETECTED"
    Write-Output "The user's prompt mentions production. Any change here is high-stakes."
    Write-Output "- Default to plan mode unless the user explicitly says 'execute' or 'ship'"
    Write-Output "- Refuse destructive operations unless explicitly confirmed"
    Write-Output "- For deploys, follow .claude/skills/deploy/SKILL.md exactly"
}
exit 0
