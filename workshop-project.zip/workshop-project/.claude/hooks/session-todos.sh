#!/bin/bash
# SessionStart — inject open todos at the start of a session.
# Output is added to Claude's context (Claude sees it at session start).
if [ -f TODO.md ]; then
  echo ""
  echo "## Session start: open todos from TODO.md"
  cat TODO.md
  echo ""
  echo "Reference these when suggesting what to work on next."
fi
exit 0
