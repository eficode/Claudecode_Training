#!/bin/bash
# Shared helper for hooks. Provides json_get that uses jq if available, falls back to python3.

json_get() {
  # Args: <json-string> <dotted-path-without-leading-dot> [default]
  # Example: json_get "$INPUT" tool_name unknown
  #          json_get "$INPUT" tool_input.command ""
  local input="$1"
  local path="$2"
  local default="${3:-}"

  if command -v jq >/dev/null 2>&1; then
    local result
    result=$(printf '%s' "$input" | jq -r ".$path // empty" 2>/dev/null)
    [ -z "$result" ] && result="$default"
    printf '%s' "$result"
  else
    printf '%s' "$input" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read() or '{}')
keys = '''$path'''.split('.')
v = data
for k in keys:
    if isinstance(v, dict): v = v.get(k, '')
    else: v = ''; break
print(v if v not in ('', None) else '''$default''')
"
  fi
}
