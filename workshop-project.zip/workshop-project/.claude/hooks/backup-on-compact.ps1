# PreCompact — save transcript before compaction.
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
New-Item -ItemType Directory -Force -Path "backups" | Out-Null
$input | Out-String | Set-Content -Path "backups/precompact-$ts.json"
exit 0
