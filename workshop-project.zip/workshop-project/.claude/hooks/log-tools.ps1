# PostToolUse log — Windows variant.
$inputJson = $input | Out-String
$data = $inputJson | ConvertFrom-Json -ErrorAction SilentlyContinue
$tool = if ($data.tool_name) { $data.tool_name } else { "unknown" }
$ts = Get-Date -Format "HH:mm:ss"
Add-Content -Path "claude-tool-log.txt" -Value "[$ts] $tool"
exit 0
