#!/bin/bash
# PreCompact — save the pre-compaction transcript JSON to disk.
# Async so it doesn't slow down compaction.
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p backups
cat > "backups/precompact-$TS.json"
exit 0
