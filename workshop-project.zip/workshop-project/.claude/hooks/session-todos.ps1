# SessionStart — inject open todos.
if (Test-Path "TODO.md") {
    Write-Output ""
    Write-Output "## Session start: open todos from TODO.md"
    Get-Content "TODO.md"
    Write-Output ""
    Write-Output "Reference these when suggesting what to work on next."
}
exit 0
