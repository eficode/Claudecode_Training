# PreToolUse secret detector — Windows variant.
$inputJson = $input | Out-String
$data = $inputJson | ConvertFrom-Json -ErrorAction SilentlyContinue
$content = if ($data.tool_input.new_string) { $data.tool_input.new_string } elseif ($data.tool_input.content) { $data.tool_input.content } else { "" }

$patterns = @(
    'AKIA[0-9A-Z]{16}',
    'ghp_[A-Za-z0-9]{20,}',
    'xox[baprs]-[0-9]+-[0-9]+',
    'sk_live_[A-Za-z0-9]+',
    '-----BEGIN [A-Z ]*PRIVATE KEY-----'
)
foreach ($p in $patterns) {
    if ($content -match $p) {
        [Console]::Error.WriteLine("BLOCKED: edit appears to contain a hardcoded secret.")
        [Console]::Error.WriteLine("Use environment variables or a secret manager instead.")
        exit 2
    }
}
exit 0
