# Hooks

Each hook has both a `.sh` (macOS/Linux) and `.ps1` (Windows) version.

`.claude/settings.json` currently references the `.sh` versions. On Windows, either:

1. **Use Git Bash**: install Git for Windows; the `.sh` scripts run via Git Bash automatically when Claude Code detects it.
2. **Switch to PowerShell**: edit `settings.json` to invoke each hook via:
   ```
   "command": "powershell -NoProfile -ExecutionPolicy Bypass -File .claude/hooks/<name>.ps1"
   ```

## What each hook does

| Hook | Event | Purpose |
|------|-------|---------|
| `log-tools` | PostToolUse | Append every tool call to `claude-tool-log.txt` |
| `block-delete` | PreToolUse(Bash) | Block `rm -rf`-style destructive commands |
| `check-secrets` | PreToolUse(Edit\|Write) | Block edits that introduce hardcoded secrets |
| `prod-guard` | UserPromptSubmit | Inject warning when user mentions production |
| `session-todos` | SessionStart | Load TODO.md into the session context |
| `backup-on-compact` | PreCompact | Save transcript JSON before compaction |
| `inject-context` | UserPromptSubmit | (Optional) Attach recent errors from app.log |

The kata 06 exercises will walk through extending these and adding new ones (including a `prompt`-type hook that uses Haiku as a security judge).
