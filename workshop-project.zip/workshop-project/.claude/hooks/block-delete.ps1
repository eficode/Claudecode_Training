# PreToolUse blocker for destructive deletes — Windows variant.
$inputJson = $input | Out-String
$data = $inputJson | ConvertFrom-Json -ErrorAction SilentlyContinue
$cmd = if ($data.tool_input.command) { $data.tool_input.command } else { "" }

if ($cmd -match '\brm\s+-rf\b|\brm\s+-r\b|\brmdir\b|Remove-Item.*-Recurse.*-Force') {
    [Console]::Error.WriteLine("BLOCKED: destructive delete is not allowed in this project.")
    [Console]::Error.WriteLine("Remove files one at a time with explicit paths.")
    exit 2
}
exit 0
