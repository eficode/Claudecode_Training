#!/bin/bash
# PreToolUse(Edit|Write) — block hardcoded-secret patterns. Regex-based.
# For nuanced detection, see kata 06 task 5 (prompt-type hook).
source "$(dirname "$0")/_lib.sh"

INPUT=$(cat)
CONTENT=$(json_get "$INPUT" tool_input.new_string "")
[ -z "$CONTENT" ] && CONTENT=$(json_get "$INPUT" tool_input.content "")

if echo "$CONTENT" | grep -qiE '(AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|xox[baprs]-[0-9]+-[0-9]+|sk_live_[A-Za-z0-9]+|-----BEGIN [A-Z ]*PRIVATE KEY-----)'; then
  echo "BLOCKED: edit appears to contain a hardcoded secret (AWS key, GitHub token, Slack token, Stripe key, or private key)." >&2
  echo "Use environment variables or a secret manager instead." >&2
  exit 2
fi
exit 0
