#!/bin/bash
# UserPromptSubmit — optional. Attaches recent errors from app.log when user mentions errors.
# Not wired by default; enable in kata 06 by adding it under UserPromptSubmit in settings.json.
source "$(dirname "$0")/_lib.sh"

INPUT=$(cat)
PROMPT=$(json_get "$INPUT" prompt "")

if echo "$PROMPT" | grep -qiE '\b(error|exception|stack trace|failure|broken)\b'; then
  if [ -f app.log ]; then
    echo ""
    echo "## Most recent error from app.log:"
    grep -iE 'error|exception|traceback' app.log | tail -10
    echo ""
  fi
fi
exit 0
