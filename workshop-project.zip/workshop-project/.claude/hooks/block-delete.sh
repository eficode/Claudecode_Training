#!/bin/bash
# PreToolUse(Bash) — block destructive deletes.
source "$(dirname "$0")/_lib.sh"

INPUT=$(cat)
CMD=$(json_get "$INPUT" tool_input.command "")
if echo "$CMD" | grep -qiE '(\brm\s+-rf\b|\brm\s+-r\b|\brmdir\b)'; then
  echo "BLOCKED: destructive delete is not allowed in this project." >&2
  echo "If you need to remove files, do it one at a time with explicit paths." >&2
  exit 2
fi
exit 0
