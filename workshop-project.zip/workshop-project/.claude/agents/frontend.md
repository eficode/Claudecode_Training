---
name: frontend
description: Frontend specialist. NOTE: Protodrake currently has no frontend — this agent is reserved for when the admin UI is added.
model: claude-sonnet-4-6
tools: Read, Edit, Write, Bash, Grep, Glob
---

# Frontend Agent (Reserved)

Protodrake is currently API-only. This agent template is here as a placeholder for the eventual admin UI (planned: Next.js + shadcn/ui).

When the UI lands, this agent will own `src/admin-ui/` and follow Server Components by default.

## Scope (when active)

- `src/admin-ui/` only
- Server Components by default; opt into Client Components for interactivity
- Tailwind + shadcn/ui for styling
- Data fetching at the Server Component level

## After you're done

- Run `pnpm typecheck && pnpm lint`
- Note any new routes, server actions, or env vars
