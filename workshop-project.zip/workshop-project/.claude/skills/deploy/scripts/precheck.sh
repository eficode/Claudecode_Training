#!/bin/bash
# Preflight checks before deploy. Exit non-zero on any failure.
set -e

ENV="${1:-dev}"

echo "→ Checking working directory is clean..."
if [ -n "$(git status --porcelain 2>/dev/null)" ]; then
  echo "❌ Working directory has uncommitted changes" >&2
  exit 1
fi

echo "→ Checking we're on main (or confirming non-main)..."
BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [ "$BRANCH" != "main" ] && [ "$ENV" = "production" ]; then
  echo "❌ Refusing to deploy non-main branch '$BRANCH' to production" >&2
  exit 1
fi

echo "→ Running tests..."
if command -v pytest >/dev/null 2>&1; then
  pytest -q || { echo "❌ Tests failed"; exit 1; }
else
  echo "⚠️  pytest not found, skipping (this is fine for the workshop)"
fi

echo "✅ Preflight checks passed for env=$ENV branch=$BRANCH"
