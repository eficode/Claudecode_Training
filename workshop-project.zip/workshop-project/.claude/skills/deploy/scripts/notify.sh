#!/bin/bash
# Post a deploy summary to Slack. In the workshop, just echoes.
SERVICE="${1:-protodrake-api}"
ENV="${2:-dev}"
COMMIT=$(git rev-parse --short HEAD)
USER=$(git config user.name || echo "unknown")
TS=$(date '+%Y-%m-%d %H:%M:%S')

# Real version would POST to $SLACK_WEBHOOK_URL
echo "📢 Deploy: $SERVICE → $ENV @ $COMMIT by $USER at $TS"
