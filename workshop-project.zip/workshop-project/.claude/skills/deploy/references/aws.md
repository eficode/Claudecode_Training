# AWS Deploy Runbook

## Prerequisites
- `aws` CLI authenticated (`aws sts get-caller-identity` should work)
- `ECR_REPO` env var set: `123456789.dkr.ecr.eu-north-1.amazonaws.com/protodrake`

## Build and push image

```bash
TAG=$(git rev-parse --short HEAD)
docker build -f infra/Dockerfile -t protodrake:$TAG .
aws ecr get-login-password | docker login --username AWS --password-stdin $ECR_REPO
docker tag protodrake:$TAG $ECR_REPO:$TAG
docker push $ECR_REPO:$TAG
```

## Update ECS service

```bash
aws ecs update-service \
  --cluster protodrake-$ENV \
  --service protodrake-api \
  --force-new-deployment \
  --task-definition protodrake-api:$TAG
```

## Verify

```bash
aws ecs wait services-stable --cluster protodrake-$ENV --services protodrake-api
curl -fsS https://protodrake-$ENV.example.com/health
```
