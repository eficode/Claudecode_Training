# GCP Deploy Runbook

## Prerequisites
- `gcloud` CLI authenticated (`gcloud auth list`)
- Project set: `gcloud config set project protodrake-$ENV`

## Build and push

```bash
TAG=$(git rev-parse --short HEAD)
gcloud builds submit --tag europe-west4-docker.pkg.dev/protodrake-$ENV/api/protodrake:$TAG
```

## Deploy to Cloud Run

```bash
gcloud run deploy protodrake-api \
  --image europe-west4-docker.pkg.dev/protodrake-$ENV/api/protodrake:$TAG \
  --region europe-west4 \
  --no-allow-unauthenticated \
  --set-env-vars "ENV=$ENV"
```

## Verify

```bash
gcloud run services describe protodrake-api --region europe-west4 \
  --format='value(status.url)' | xargs -I{} curl -fsS {}/health
```
