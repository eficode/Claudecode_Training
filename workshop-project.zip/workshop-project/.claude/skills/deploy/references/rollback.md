# Rollback Runbook

## AWS (ECS)

Find the previous task definition revision:
```bash
aws ecs describe-services --cluster protodrake-$ENV --services protodrake-api \
  | jq -r '.services[0].deployments'
```

Roll back to a known-good revision:
```bash
aws ecs update-service \
  --cluster protodrake-$ENV \
  --service protodrake-api \
  --task-definition protodrake-api:$PREVIOUS_REVISION
```

## GCP (Cloud Run)

List revisions:
```bash
gcloud run revisions list --service protodrake-api --region europe-west4
```

Route 100% of traffic to a previous revision:
```bash
gcloud run services update-traffic protodrake-api \
  --to-revisions $PREVIOUS_REVISION=100 \
  --region europe-west4
```

## After rollback
- Open an incident ticket
- Notify #incidents in Slack with: cause, impact window, rollback target, next steps
