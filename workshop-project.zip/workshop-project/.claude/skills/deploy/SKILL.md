---
name: deploy
description: Deploy the API to dev, staging, or production. Performs preflight checks, reads cloud-specific runbook, deploys, then notifies. Use when the user wants to deploy, ship, push to env, or release.
allowed-tools: Read, Bash, Grep
argument-hint: [environment]
---

# Deploy Skill

## Quick start

1. Run `scripts/precheck.sh $ARGUMENTS` — fails fast if branch is dirty or tests are red.
2. Determine target cloud:
   - AWS → see `references/aws.md`
   - GCP → see `references/gcp.md`
3. Execute deploy via the provider-specific commands from the reference.
4. Run `scripts/notify.sh "<service>" "<env>"` to post deploy summary to Slack.
5. Validate with `curl -fsS $DEPLOY_URL/health` — expect `{"status":"ok"}`.

## On failure

If anything in steps 1–5 fails:
1. Stop immediately. Do not proceed to the next step.
2. Read `references/rollback.md` and follow the rollback runbook.
3. Report what failed, what state the system is in, and what action you took.

## Gotchas

- If `precheck.sh` exits non-zero, **do not proceed** under any circumstance.
- Never deploy from a non-`main` branch without explicit user confirmation.
- Production deploys require the `--confirm-prod` flag — refuse otherwise.
