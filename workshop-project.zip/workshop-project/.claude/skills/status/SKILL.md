---
name: status
description: Show project status using live git context. Manual invocation only.
disable-model-invocation: true
---

## Current Project Status

**Branch:** !`git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "no git"`
**Last 3 commits:** !`git log --oneline -3 2>/dev/null || echo "no commits"`
**Working tree:** !`git status --short 2>/dev/null || echo "clean"`
**Open todos:** !`cat TODO.md 2>/dev/null | grep -c "^- \[ \]" || echo "0"` items in TODO.md
**Tests last run:** !`stat -c '%y' .pytest_cache/CACHEDIR.TAG 2>/dev/null || stat -f '%Sm' .pytest_cache/CACHEDIR.TAG 2>/dev/null || echo "never"`

Based on this context, summarize what's currently happening in this project and suggest a sensible next thing to work on. Cross-reference the open todos in TODO.md against the recent commits — what's been started but not finished?
