#!/bin/bash
# Trivial complexity score: counts branching constructs.
# Used by /review to inject a deterministic number into the review.
FILE="$1"
if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
  echo "complexity: file not found: $FILE" >&2
  exit 1
fi
N=$(grep -cE '\b(if|for|while|switch|case|except|elif)\b' "$FILE")
LINES=$(wc -l < "$FILE")
echo "Complexity: $N branches across $LINES lines"
