# Python Review Checklist

## Bugs
- Mutable default args (`def f(x=[]):`)
- `except:` or `except Exception:` without re-raise or logging
- Using `==` with `None` instead of `is None`
- Off-by-one in slicing, range, enumerate
- `assert` used for runtime validation (gets stripped with `-O`)

## Performance
- Loops where comprehensions or generator expressions would be clearer/faster
- `+= str` inside a hot loop (use `"".join(...)`)
- Repeated dict/list lookups instead of binding to a local

## Type / API design
- Missing return type annotation on public functions
- `Optional[X]` instead of `X | None` (this codebase uses 3.11+ style)
- Public functions without docstrings
- Functions doing more than one thing

## Style
- `from module import *`
- Inconsistent quote style within a file
- Comments that describe *what* instead of *why*
