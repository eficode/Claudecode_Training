# General Review Checklist (language-agnostic)

- Function does more than one thing — split it
- Names that don't reflect behavior — rename
- Magic numbers without explanation — extract to constant
- Duplicated logic across files — extract to shared module
- Comments out of sync with code — update or delete
- Dead code (unreachable, unused) — remove
- Edge cases not handled: empty input, max input, concurrent calls, partial failure
