# JavaScript/TypeScript Review Checklist

## Bugs
- Equality with `==` instead of `===`
- Missing null/undefined check on optional fields
- Mixing async/await and `.then()` in the same function
- Missing `await` on a Promise-returning call
- Mutation of function arguments
- Floating-point arithmetic on money (use cents as integers)

## Patterns
- `for (let i = 0; i < arr.length; i++)` where `.map()`/`.forEach()` reads clearer
- Promise chains without error handling
- `try` blocks that swallow errors silently

## TypeScript-specific
- `any` types (should be `unknown` or a specific type)
- `as Type` casts without a runtime check
- Missing return type on exported functions
