---
name: review
description: Review code for bugs, performance, readability, and style issues. Use when the user asks to review, audit, or critique a file. Reads language-specific checklist from references/ and runs a complexity script.
allowed-tools: Read, Grep, Glob, Bash
argument-hint: [file-path]
---

# Code Review Skill

## Quick start

1. Read the target file: `$ARGUMENTS`
2. Identify the language by extension.
3. Read the matching reference checklist:
   - `.py` → see `references/python.md`
   - `.js` / `.ts` → see `references/javascript.md`
   - other → use `references/general.md`
4. Run `scripts/complexity.sh $ARGUMENTS` and include the score in your output.
5. Produce a numbered list of findings.

## Output format

For each finding:

```
N. [SEVERITY] line <num>: <one-sentence problem>
   Fix: <one-sentence fix>
```

Severity: LOW, MEDIUM, HIGH. Cap at 10 findings; prioritize HIGH first.

## When NOT to use this

- Don't review files larger than 1000 lines — split or use a fork-context skill instead
- Don't review tests with the same checklist — testing.md applies different rules
