---
name: db-migrate
description: Generate or run a database migration. Use when the user wants to add/change a column, table, or index, or migrate to a new schema.
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
argument-hint: [describe-the-change]
---

# DB Migration Skill

## Quick start

1. Read the current models in `src/db/models.py`
2. Plan the schema change in plain English. Show me the diff before writing code.
3. Update `src/db/models.py` with the new schema.
4. Generate the Alembic migration:
   ```bash
   alembic revision --autogenerate -m "<short-description>"
   ```
   (Workshop note: Alembic isn't wired up in this fake project. Hand-write the migration file in `migrations/versions/` instead.)
5. **Review the generated migration carefully** — autogenerate is approximate.
6. Update tests in `tests/integration/` if the change affects HTTP responses.

## Gotchas

- Add NEW columns as `nullable=True` first, backfill, THEN change to NOT NULL in a second migration. Never both in one.
- Adding an index on a large table is non-trivial — use `CREATE INDEX CONCURRENTLY` and document the runtime.
- Dropping a column? Soft-deprecate first (one release), drop in the next.
- Always test the migration in a copy of staging data before production.

## What this skill will NOT do

- Run migrations against production — that's a manual operation
- Modify data without an explicit data migration script in `migrations/data/`
