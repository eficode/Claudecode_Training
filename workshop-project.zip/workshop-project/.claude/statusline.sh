#!/bin/bash
# Custom statusline — shows model, branch, context %, cost.
# Works with or without jq (falls back to python3).
source "$(dirname "$0")/hooks/_lib.sh"

INPUT=$(cat)
MODEL=$(json_get "$INPUT" model.id "?")
MODEL=$(echo "$MODEL" | sed 's/^claude-//;s/-[0-9].*$//')
DIR_PATH=$(json_get "$INPUT" workspace.current_dir ".")
DIR=$(basename "$DIR_PATH")
CTX=$(json_get "$INPUT" context_window.used_percentage "0")
CTX=$(printf '%.0f' "${CTX:-0}" 2>/dev/null || echo 0)
COST=$(json_get "$INPUT" cost.total_cost_usd "0")
COST=$(printf '$%.2f' "${COST:-0}" 2>/dev/null || echo '$0.00')
BRANCH=$(git -C "$DIR_PATH" rev-parse --abbrev-ref HEAD 2>/dev/null || echo "-")

# Color the context % yellow at 50, red at 75
if [ "$CTX" -gt 75 ] 2>/dev/null; then
  CTX_DISPLAY=$(printf '\033[31m%s%%\033[0m' "$CTX")
elif [ "$CTX" -gt 50 ] 2>/dev/null; then
  CTX_DISPLAY=$(printf '\033[33m%s%%\033[0m' "$CTX")
else
  CTX_DISPLAY="${CTX}%"
fi

printf "📂 %s | 🌿 %s | 🤖 %s | 💭 %b ctx | 💸 %s" "$DIR" "$BRANCH" "$MODEL" "$CTX_DISPLAY" "$COST"
