# API Guidelines (path-scoped: src/api/)

## URL Structure
- All app routes under `/api/<resource>/`
- Plural nouns: `/api/users/`, `/api/content/`, `/api/moderation/`
- No verbs in URLs (use HTTP methods instead)
- Trailing slashes are kept consistent (we use trailing)

## Status Codes
| Code | Use |
|------|-----|
| 200 | Successful GET or PATCH |
| 201 | Successful POST that creates a resource |
| 204 | Successful DELETE (no body) |
| 400 | Validation failed |
| 401 | Missing or invalid auth |
| 403 | Auth OK but forbidden |
| 404 | Resource not found |
| 409 | Conflict (duplicate, state mismatch) |
| 422 | FastAPI's own validation errors (don't override) |
| 429 | Rate limit exceeded |

## Errors
Always return a JSON body:
```json
{ "error": "machine_readable_code", "message": "Human-readable explanation" }
```

The `error` field is what clients branch on. Don't change existing codes — add new ones.

## Pagination
- Default `limit=50`, max `limit=200`
- Always include `offset` OR `cursor`, never both
- For high-cardinality lists (audit log, content), prefer cursor
