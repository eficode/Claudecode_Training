# Security Rules (apply everywhere)

## Hardcoded secrets — ABSOLUTELY NEVER
- No API keys, passwords, tokens, or secrets in source code
- No `.env` files committed — `.env.example` only
- The `check-secrets.sh` hook scans Edit/Write — it will block you
- If a secret leaks: rotate it immediately, then remove from git history

## Input validation
- Validate at the route boundary via Pydantic schemas
- Treat anything from the wire as hostile until proven otherwise
- Use `Field(max_length=N)` on strings — never accept unbounded text

## SQL
- All queries through SQLAlchemy — never raw SQL with f-strings
- If you must use raw SQL, use parameterized queries with `text(":param")`

## Auth
- Auth middleware lives in `src/api/middleware/` (TODO — not yet implemented)
- When implemented: validate JWT signature, check expiry, fetch user
- Never trust the `Authorization` header without verification

## Logging
- Never log full request bodies (may contain PII or secrets)
- Never log auth tokens or passwords
- Log user IDs, not emails
