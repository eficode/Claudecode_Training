# Testing Rules (path-scoped: tests/)

## What goes where
- `tests/unit/` — pure function tests, service layer
- `tests/integration/` — HTTP via the `client` fixture
- `tests/e2e/` — reserved for when we have real infrastructure (not yet)

## Conventions
- Test functions: `test_<what>_<expected_behavior>` — e.g., `test_create_user_returns_201`
- One assertion concept per test (multiple assert statements are fine if they test one behavior)
- Use `pytest.mark.parametrize` for table-driven tests
- Use `pytest.raises` for expected exceptions; check the message with `match=`

## Don't
- Don't mock what you own (the service layer) in integration tests — use the real thing
- Don't share mutable state between tests without explicit fixtures
- Don't `time.sleep` — use `freezegun` or refactor the code to be testable
