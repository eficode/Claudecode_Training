# Code Style Rules

These rules apply to **all Python code** under `src/` and `tests/`.

## Formatting
- ruff format handles all formatting — never hand-format
- Line length: 100 characters (set in pyproject.toml)
- Two blank lines between top-level functions/classes; one within classes

## Naming
- `snake_case` for functions, variables, modules
- `PascalCase` for classes (including Pydantic models)
- `SCREAMING_SNAKE_CASE` for module-level constants only
- Private helpers prefixed with `_`

## Type Annotations
- Every public function has a return type annotation
- Use `str | None` style unions (not `Optional[str]`) — Python 3.11+
- Use `list[X]` and `dict[K, V]` (not `List`/`Dict`) — `typing` imports for those are deprecated style here

## Imports
- Absolute imports from `src.*`
- One import per line for `from` imports with more than 3 names
- ruff handles ordering — do not hand-sort

## Strings
- Double quotes by default
- f-strings for interpolation
- Triple-quoted docstrings on every public function
