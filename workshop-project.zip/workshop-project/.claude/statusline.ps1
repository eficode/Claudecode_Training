# Windows statusline — invoke via: powershell -NoProfile -File .claude/statusline.ps1
$inputJson = $input | Out-String
$data = $inputJson | ConvertFrom-Json -ErrorAction SilentlyContinue
$model = if ($data.model.id) { ($data.model.id -replace '^claude-','' -replace '-[0-9].*$','') } else { "?" }
$dir = if ($data.workspace.current_dir) { Split-Path -Leaf $data.workspace.current_dir } else { "." }
$ctx = if ($data.context_window.used_percentage) { [math]::Round($data.context_window.used_percentage) } else { 0 }
$cost = if ($data.cost.total_cost_usd) { "{0:C2}" -f $data.cost.total_cost_usd } else { '$0.00' }
$branch = try { (git -C $data.workspace.current_dir rev-parse --abbrev-ref HEAD 2>$null) } catch { "-" }
if (-not $branch) { $branch = "-" }
"📂 $dir | 🌿 $branch | 🤖 $model | 💭 $($ctx)% ctx | 💸 $cost"
