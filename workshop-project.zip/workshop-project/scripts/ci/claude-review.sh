#!/bin/bash
# Headless Claude Code review for pull requests.
# Invoked by .github/workflows/claude-review.yml.
set -e

DIFF=$(git diff origin/main...HEAD)
if [ -z "$DIFF" ]; then
  echo "No diff to review."
  exit 0
fi

# Use plan-mode headless Claude to review the diff
claude -p "Review this PR diff. Focus on: security issues, layering violations (route→service→db), missing tests, breaking API changes. Be terse. Use the format used by the /review skill.

$DIFF" \
  --permission-mode plan \
  --max-turns 3
