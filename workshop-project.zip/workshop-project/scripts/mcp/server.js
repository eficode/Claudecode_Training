// Workshop-bundled MCP server.
// Kata 07 walks through extending this with an elicitation-based deploy tool.
//
// Run setup first:
//   cd scripts/mcp && npm install
//
// It's registered in /.mcp.json at the project root, so Claude Code picks it
// up automatically when you run `claude` from the repo root.

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import fs from "fs";

const server = new McpServer({ name: "workshop-tools", version: "1.0.0" });

// ---------------------------------------------------------------------------
// Basic tools — covered in kata 07's fundamentals section
// ---------------------------------------------------------------------------

server.tool("generate_uuid", "Generate a random UUID v4", {}, async () => ({
  content: [{ type: "text", text: crypto.randomUUID() }],
}));

server.tool(
  "count_words",
  "Count words in a given text",
  { text: z.string().describe("The text to count words in") },
  async ({ text }) => ({
    content: [
      {
        type: "text",
        text: `Word count: ${text.trim().split(/\s+/).filter(Boolean).length}`,
      },
    ],
  })
);

server.tool(
  "format_json",
  "Pretty-print a JSON string",
  { json: z.string().describe("JSON string to format") },
  async ({ json }) => {
    try {
      return {
        content: [
          { type: "text", text: JSON.stringify(JSON.parse(json), null, 2) },
        ],
      };
    } catch (e) {
      return {
        content: [{ type: "text", text: `Invalid JSON: ${e.message}` }],
        isError: true,
      };
    }
  }
);

// ---------------------------------------------------------------------------
// Elicitation tool — covered in kata 07's novel layer
// The deploy tool pauses execution and asks the user for structured input
// (target env + confirmation) via an interactive dialog, then continues.
// ---------------------------------------------------------------------------

server.tool(
  "deploy",
  "Deploy the current branch. Asks the user which environment via an interactive dialog before proceeding.",
  { service: z.string().describe("Service name to deploy") },
  async ({ service }, { server: srv }) => {
    const response = await srv.elicitInput({
      message: `You're about to deploy '${service}'. Confirm the target environment.`,
      requestedSchema: {
        type: "object",
        required: ["env", "confirmed"],
        properties: {
          env: {
            type: "string",
            enum: ["dev", "staging", "production"],
            description: "Target environment",
          },
          confirmed: {
            type: "boolean",
            description: "I have verified this deploy is safe",
          },
          notes: {
            type: "string",
            description: "Optional deploy notes (will appear in audit log)",
          },
        },
      },
    });

    if (response.action !== "accept") {
      return { content: [{ type: "text", text: `Deploy cancelled by user.` }] };
    }

    const { env, confirmed, notes } = response.content;
    if (!confirmed) {
      return {
        content: [
          { type: "text", text: `Deploy aborted: confirmation checkbox was not ticked.` },
        ],
      };
    }

    // In real life: kick off the actual deploy. For the workshop we just record.
    const summary = `✅ Deployed '${service}' to ${env}${notes ? `. Notes: ${notes}` : ""}`;
    return { content: [{ type: "text", text: summary }] };
  }
);

// ---------------------------------------------------------------------------
// Resource — project info, kept simple for kata 07 bonus
// ---------------------------------------------------------------------------

server.resource("project-info", "project://info", async (uri) => {
  let pkg = { name: "protodrake", version: "0.1.0" };
  try {
    const raw = fs.readFileSync("./pyproject.toml", "utf-8");
    const versionMatch = raw.match(/^version\s*=\s*"([^"]+)"/m);
    if (versionMatch) pkg.version = versionMatch[1];
  } catch {}
  return {
    contents: [
      {
        uri: uri.href,
        mimeType: "application/json",
        text: JSON.stringify(pkg, null, 2),
      },
    ],
  };
});

// ---------------------------------------------------------------------------
// Connect via stdio
// ---------------------------------------------------------------------------

const transport = new StdioServerTransport();
await server.connect(transport);
