# Workshop MCP Server

Bundled MCP server for kata 07. Three basic tools (`generate_uuid`, `count_words`, `format_json`), one elicitation-driven tool (`deploy`), and one resource (`project://info`).

## Setup (once)

```bash
cd scripts/mcp
npm install
```

That's all — `.mcp.json` at the project root already registers this server, so when you run `claude` from the project root the server starts automatically.

## Verifying it loaded

In a Claude session:

```
/mcp
```

You should see `workshop-tools` listed with five capabilities (4 tools + 1 resource).

## Trying the tools

- `"Generate a UUID"` — calls `generate_uuid`
- `"Count words in: the quick brown fox"` — calls `count_words`
- `"Format this JSON: {\"a\":1}"` — calls `format_json`
- `"Deploy the user-service"` — calls `deploy`, opens a form dialog asking which env

The `deploy` tool is the kata 07 highlight: it pauses mid-execution, shows you a form, then continues with your answer. Game-changer for high-stakes operations.

## Adding your own tool

Edit `server.js`. Add a `server.tool(name, description, schema, handler)` block. Restart Claude (the server reloads on every session start).
