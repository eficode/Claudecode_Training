# Spec: Pricing v2 (Draft)

**Status:** Draft
**Author:** Workshop participant
**Created:** 2026-05-15
**Implements:** Issue #142

## Problem

Pricing v1 charges flat per-submission. Heavy users subsidize light ones. We want a tiered model with included quotas.

## Proposed Tiers

| Tier | Monthly fee | Included submissions | Overage |
|------|-------------|----------------------|---------|
| Free | $0 | 100 | n/a — hard cap |
| Starter | $19 | 5,000 | $0.005/item |
| Pro | $99 | 50,000 | $0.003/item |
| Enterprise | custom | custom | custom |

## API Changes

- New endpoint: `GET /api/billing/usage` — returns current period usage
- New header on `/api/content/` responses: `X-RateLimit-Remaining`
- New error: `429 quota_exceeded` (free tier hard cap)

## Open Questions

- How do we handle tier downgrades mid-period?
- Should moderation count against the submitter's quota?
- What's our policy on usage spikes for Pro customers?

## Out of Scope

- Annual billing discounts
- Multi-org billing rollups
- Usage-based pricing for moderators (separate spec)
