# docs/specs/ — Design Specs

Specs live here before they become code. Each spec is a markdown file named `<YYYY-MM>-<slug>.md`.

## Template

```markdown
# Spec: <Title>

**Status:** Draft | In Review | Approved | Implemented | Superseded
**Author:** <name>
**Created:** YYYY-MM-DD
**Implements:** Issue #<number>

## Problem
What user pain or technical debt this addresses.

## Proposal
The design. Diagrams welcome.

## API Changes
Endpoints, request/response shapes, error codes.

## Open Questions
Things you don't know yet. List them so reviewers can answer.

## Out of Scope
What this spec explicitly does NOT cover.
```

## Process

1. Open a draft PR with the spec
2. Get sign-off from at least one other engineer
3. Mark **Approved** and merge to `main`
4. Implementation PRs reference the spec in their description
5. When complete, update spec status to **Implemented** in a follow-up PR

## Working with Claude

When asking Claude to implement a spec, point it at the file:

> "Implement the changes described in `docs/specs/2026-05-pricing-v2.md`. Use plan mode first. Don't deviate from the spec."

This is dramatically more reliable than describing the spec inline.
