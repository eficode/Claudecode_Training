# Protodrake Architecture

## High-Level

```
              ┌──────────────────┐
   HTTPS ─►   │   FastAPI app    │
              │  (uvicorn)       │
              └─┬────────────┬───┘
                │            │
                ▼            ▼
        ┌──────────┐  ┌──────────┐
        │ Postgres │  │  Redis   │
        │ (state)  │  │ (queue)  │
        └──────────┘  └──────────┘
```

## Layers

| Layer | Path | Responsibility |
|-------|------|----------------|
| **Route** | `src/api/routes/` | HTTP boundary, request validation, status codes |
| **Service** | `src/services/` | Business logic, transaction boundaries |
| **DB** | `src/db/` | SQLAlchemy models, session factory |
| **Lib** | `src/lib/` | Cross-cutting helpers (errors, cache) |

Layering rule: routes call services; services call db + lib. **Never** the reverse.

## Data Model

Three primary tables:

- **users** — id, email (unique), display_name, role, created_at
- **content** — id, author_id (FK users), kind, body, submitted_at, status
- **moderation_audit** — id, content_id (FK), moderator_id (FK users), decision, reason, decided_at

The moderation queue itself lives in Redis (`moderation:queue` list) so it doesn't compete with the OLTP database.

## Moderation Flow

1. User POSTs to `/api/content/`
2. Service writes the row (status=pending) and pushes the id to `moderation:queue`
3. Moderator GETs `/api/moderation/queue?moderator_id=N` — items are claimed for 10 min
4. Moderator POSTs to `/api/moderation/decisions` — content row's status updates, audit row inserted

## Deployment

- Container built from `infra/Dockerfile`
- Pushed to ECR (AWS) or Artifact Registry (GCP)
- Deployed via ECS Fargate or Cloud Run
- See `.claude/skills/deploy/` for the runbook
