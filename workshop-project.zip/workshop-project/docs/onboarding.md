# Onboarding

Welcome to Protodrake. This service handles content moderation across the platform.

## Day 1

1. Get the repo running locally (see top-level README)
2. Run `pytest` — make sure everything's green
3. Hit `/health` in your browser via `http://localhost:8000/health`
4. Submit a test piece of content via curl or HTTPie
5. Read `docs/architecture.md` end to end

## Day 2 — Claude Code

This repo is configured for Claude Code with skills, hooks, agents, and an MCP server. See:

- `CLAUDE.md` (root) — start here
- `.claude/agents/` — specialist subagents
- `.claude/skills/` — custom slash commands like `/review`, `/deploy`, `/status`
- `scripts/mcp/` — bundled MCP server with workshop tools

## Common Commands

```bash
# Run dev server with reload
uvicorn src.api:app --reload

# Run tests (and watch)
pytest                          # one-off
pytest --watch                  # if pytest-watch installed

# Lint and type-check
ruff check src/ tests/
ruff format src/ tests/

# Open Claude Code in this repo
claude
```
