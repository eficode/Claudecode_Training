# Open Todos

- [ ] Wire up real Postgres connection (currently uses in-memory store in services/)
- [ ] Add rate limiting middleware to /api/content/ — see spec at docs/specs/2026-05-pricing-v2.md
- [ ] Investigate flaky integration test: test_submit_and_moderate_flow (sometimes fails on CI)
- [ ] Replace `Optional[str]` with `str | None` across src/ for Python 3.11 style consistency
- [ ] Audit error responses — some endpoints still leak internal error messages
